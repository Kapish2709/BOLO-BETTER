# BoloBetter — Streamlit Cloud Version

Speak Hindi → Get translated + 3 polished English versions → Hear them back.
Runs entirely in the browser via Streamlit Cloud. No local install needed.

---

## Deploy in 5 Minutes (Free)

### Step 1 — Put this on GitHub
1. Go to github.com → New repository → name it `bolobetter`
2. Upload these 3 files/folders:
   - `app.py`
   - `requirements.txt`
   - `.streamlit/config.toml`

### Step 2 — Deploy on Streamlit Cloud
1. Go to **share.streamlit.io**
2. Sign in with GitHub
3. Click **New app**
4. Select your `bolobetter` repo
5. Main file: `app.py`
6. Click **Deploy**

Your app gets a permanent public URL like:
`https://yourname-bolobetter-app-xyz123.streamlit.app`

### Step 3 — Add API Keys Securely (Optional but recommended)
Instead of typing keys every session, add them as secrets:
1. In Streamlit Cloud dashboard → your app → **Settings** → **Secrets**
2. Add:
```
SARVAM_API_KEY = "your_key_here"
OPENAI_API_KEY = "your_key_here"
```

---

## Get Your API Keys

- **Sarvam AI** (free tier available): https://dashboard.sarvam.ai
- **OpenAI**: https://platform.openai.com/api-keys

---

## Files

```
bolobetter/
├── app.py                  # Main Streamlit app
├── requirements.txt        # Python dependencies
└── .streamlit/
    └── config.toml         # Dark theme config
```

---

## Features

- Record voice directly in browser OR upload audio file
- Hindi speech → English translation via Sarvam saaras:v3
- 3 suggestions: Casual, Professional, Formal via GPT-4o
- Audio playback of each suggestion via Sarvam bulbul:v3
- Session history in sidebar
- Choose voice and speaking pace
